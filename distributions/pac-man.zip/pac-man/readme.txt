Made by Hristo Banchev � 2015.

The source can be found in: https://github.com/FanatikPriest/pac-man